package com.dicoding.project.githubuser.data.model

data class User(
    val login: String,
    val id: Int,
    val avatar_url: String
)
