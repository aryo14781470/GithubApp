package com.dicoding.project.githubuser.data.model

data class UserResponse(val items: ArrayList<User>)
